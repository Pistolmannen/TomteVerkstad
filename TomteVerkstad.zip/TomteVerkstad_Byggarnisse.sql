use TomteVerkstad;

show tables;
select * from allaVerktyg;

show procedure status;
call getLeksakerPåPris(160);